package com.gep.foro_alura.domain.topico.validaciones.actualizar;

import com.gep.foro_alura.domain.topico.ActualizarTopicoDTO;

public interface ValidarTopicoActualizado {

    public void validate(ActualizarTopicoDTO data);

}
