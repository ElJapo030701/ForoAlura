package com.gep.foro_alura.domain.respuesta;

public record ActualizarRespuestaDTO(
        String mensaje, Boolean solucion, Boolean borrado
) {
}
