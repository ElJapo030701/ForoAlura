package com.gep.foro_alura.domain.curso;

public record ActualizarCursoDTO(String name, Categoria categoria, Boolean activo) {

}


