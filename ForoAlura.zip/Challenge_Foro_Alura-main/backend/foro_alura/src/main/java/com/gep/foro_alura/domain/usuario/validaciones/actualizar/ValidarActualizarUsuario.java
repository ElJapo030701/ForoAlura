package com.gep.foro_alura.domain.usuario.validaciones.actualizar;

import com.gep.foro_alura.domain.usuario.ActualizarUsuarioDTO;

public interface ValidarActualizarUsuario {
    public void validate(ActualizarUsuarioDTO data);
}
