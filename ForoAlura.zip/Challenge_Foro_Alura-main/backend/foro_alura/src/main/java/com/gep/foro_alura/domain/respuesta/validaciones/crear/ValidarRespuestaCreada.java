package com.gep.foro_alura.domain.respuesta.validaciones.crear;

import com.gep.foro_alura.domain.respuesta.CrearRespuestaDTO;

public interface ValidarRespuestaCreada {
    public void validate(CrearRespuestaDTO data);
}
