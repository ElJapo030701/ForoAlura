package com.gep.foro_alura.domain.topico;

public enum Estado {
    OPEN,
    CLOSED,
    DELETED
}
