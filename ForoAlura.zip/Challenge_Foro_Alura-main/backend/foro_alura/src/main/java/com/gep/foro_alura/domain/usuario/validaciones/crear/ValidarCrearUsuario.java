package com.gep.foro_alura.domain.usuario.validaciones.crear;

import com.gep.foro_alura.domain.usuario.CrearUsuarioDTO;

public interface ValidarCrearUsuario {
    public void validate(CrearUsuarioDTO data);
}
